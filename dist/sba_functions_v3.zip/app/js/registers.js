// Register event clicks for buttons / action items 

// document.addEventListener("DOMContentLoaded", function() {


//     // specify elements to listen to for clicks
//     const crmInfoLink = document.getElementById("crmInfoListItem");
//     const efinInfoLink = document.getElementById("crmEfinListItem");
//     const helpDeskLink = document.getElementById("helpDeskListItem")

//     // CRM Info Listener
//     crmInfoLink.addEventListener("click", function(event) {
//       event.preventDefault(); // Prevent the default navigation behavior
//       console.log("CRM Info Link clicked!");
//       getCRMContact();
//     });

//     // EFIN Info Listener
//     efinInfoLink.addEventListener("click", function(event) {
//       event.preventDefault(); // Prevent the default navigation behavior
//       console.log("EFIN Info Link clicked!");
//       getMasterEfins();
//     });

//     // HelpDesk Info Listener
//     helpDeskLink.addEventListener("click", function(event) {
//         event.preventDefault(); // Prevent the default navigation behavior
//         console.log("helpDeskLink clicked!");
//         });
//   });
  




  